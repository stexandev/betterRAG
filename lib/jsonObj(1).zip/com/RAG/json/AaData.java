
package com.RAG.json;

import java.util.List;

public class AaData{
   	private String pND;
   	private Number date_year1;
   	private Number main_id;
   	private String pers_amt;
   	private String pers_counter;
   	private String pers_first_name1;
   	private String pers_first_name2;
   	private String pers_name_gen;
   	private String pers_name_ltgr;
   	private String pers_norm_name;
   	private String pers_patronym;
   	private String pers_praef;
   	private String pers_title;

 	public String getPND(){
		return this.pND;
	}
	public void setPND(String pND){
		this.pND = pND;
	}
 	public Number getDate_year1(){
		return this.date_year1;
	}
	public void setDate_year1(Number date_year1){
		this.date_year1 = date_year1;
	}
 	public Number getMain_id(){
		return this.main_id;
	}
	public void setMain_id(Number main_id){
		this.main_id = main_id;
	}
 	public String getPers_amt(){
		return this.pers_amt;
	}
	public void setPers_amt(String pers_amt){
		this.pers_amt = pers_amt;
	}
 	public String getPers_counter(){
		return this.pers_counter;
	}
	public void setPers_counter(String pers_counter){
		this.pers_counter = pers_counter;
	}
 	public String getPers_first_name1(){
		return this.pers_first_name1;
	}
	public void setPers_first_name1(String pers_first_name1){
		this.pers_first_name1 = pers_first_name1;
	}
 	public String getPers_first_name2(){
		return this.pers_first_name2;
	}
	public void setPers_first_name2(String pers_first_name2){
		this.pers_first_name2 = pers_first_name2;
	}
 	public String getPers_name_gen(){
		return this.pers_name_gen;
	}
	public void setPers_name_gen(String pers_name_gen){
		this.pers_name_gen = pers_name_gen;
	}
 	public String getPers_name_ltgr(){
		return this.pers_name_ltgr;
	}
	public void setPers_name_ltgr(String pers_name_ltgr){
		this.pers_name_ltgr = pers_name_ltgr;
	}
 	public String getPers_norm_name(){
		return this.pers_norm_name;
	}
	public void setPers_norm_name(String pers_norm_name){
		this.pers_norm_name = pers_norm_name;
	}
 	public String getPers_patronym(){
		return this.pers_patronym;
	}
	public void setPers_patronym(String pers_patronym){
		this.pers_patronym = pers_patronym;
	}
 	public String getPers_praef(){
		return this.pers_praef;
	}
	public void setPers_praef(String pers_praef){
		this.pers_praef = pers_praef;
	}
 	public String getPers_title(){
		return this.pers_title;
	}
	public void setPers_title(String pers_title){
		this.pers_title = pers_title;
	}
}
