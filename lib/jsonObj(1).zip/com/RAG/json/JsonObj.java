
package com.RAG.json;

import java.util.List;

public class JsonObj{
   	private List aaData;
   	private Number iTotalDisplayRecords;
   	private Number sEcho;

 	public List getAaData(){
		return this.aaData;
	}
	public void setAaData(List aaData){
		this.aaData = aaData;
	}
 	public Number getITotalDisplayRecords(){
		return this.iTotalDisplayRecords;
	}
	public void setITotalDisplayRecords(Number iTotalDisplayRecords){
		this.iTotalDisplayRecords = iTotalDisplayRecords;
	}
 	public Number getSEcho(){
		return this.sEcho;
	}
	public void setSEcho(Number sEcho){
		this.sEcho = sEcho;
	}
}
