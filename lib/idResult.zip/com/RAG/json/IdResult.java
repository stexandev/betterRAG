
package com.RAG.json;

import java.util.List;

public class IdResult{
   	private String main_id;
   	private String norm_name;
   	private String var_name;

 	public String getMain_id(){
		return this.main_id;
	}
	public void setMain_id(String main_id){
		this.main_id = main_id;
	}
 	public String getNorm_name(){
		return this.norm_name;
	}
	public void setNorm_name(String norm_name){
		this.norm_name = norm_name;
	}
 	public String getVar_name(){
		return this.var_name;
	}
	public void setVar_name(String var_name){
		this.var_name = var_name;
	}
}
